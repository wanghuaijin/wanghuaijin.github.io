LaTex Template Compiles as following steps:

- Compile `main.tex` in `LaTeX`;
- Compile `main.tex` in `BibTeX`;
- Compile `main.tex` twice in `LaTeX`.